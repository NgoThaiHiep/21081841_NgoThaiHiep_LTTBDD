import { Text, SafeAreaView, StyleSheet ,View,Image, TextInput,TouchableOpacity,FlatList,Button} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack'
import React, { useState, useEffect } from 'react';
// You can import supported modules from npm
import { Card } from 'react-native-paper';
import Icon from 'react-native-vector-icons/FontAwesome';

// or any files within the Snack
import AssetExample from './components/AssetExample';

 const Stack = createNativeStackNavigator();
export default function App(){
  return(
      <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="ListBike" component={ListBike} />
        <Stack.Screen name="AddCartBike" component={AddCartBike} />
        <Stack.Screen name="AddBike" component={AddBike} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
function AddBike({navigation}) {
  const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [img, setImg] = useState('');
    const [isLiked, setIsLiked] = useState(false);

    // Hàm gửi dữ liệu lên API
    const addProduct = async () => {
        if (!name || !price || !img) {
            alert('Vui lòng nhập đầy đủ thông tin sản phẩm');
            return;
        }

        const productData = {
            name: name,
            price: price,
            img: img,
            isLiked: isLiked,
        };

        try {
            const response = await fetch(`${api}/ListBike`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(productData),
            });

            if (response.ok) {
                alert('Thêm sản phẩm thành công!');
              navigation.navigate('ListBike');
            } else {
                alert('Lỗi khi thêm sản phẩm');
            }
        } catch (error) {
            console.log('Lỗi khi gửi dữ liệu:', error);
            alert('Có lỗi xảy ra!');
        }
    };

    return (
        <View style={{ flex: 1, padding: 20 }}>
            <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>Thêm Sản Phẩm Mới</Text>

            {/* Tên sản phẩm */}
            <TextInput
                value={name}
                onChangeText={setName}
                placeholder="Nhập tên sản phẩm"
                style={{ borderBottomWidth: 1, marginBottom: 15, padding: 10 }}
            />

            {/* Giá sản phẩm */}
            <TextInput
                value={price}
                onChangeText={setPrice}
                placeholder="Nhập giá sản phẩm"
                keyboardType="numeric"
                style={{ borderBottomWidth: 1, marginBottom: 15, padding: 10 }}
            />

            {/* Hình ảnh sản phẩm */}
            <TextInput
                value={img}
                onChangeText={setImg}
                placeholder="Nhập URL hình ảnh"
                style={{ borderBottomWidth: 1, marginBottom: 15, padding: 10 }}
            />

            {/* Checkbox cho trạng thái "Yêu thích" */}
            <TouchableOpacity
                style={{ marginBottom: 20 }}
                onPress={() => setIsLiked(!isLiked)}
            >
               
            </TouchableOpacity>

            {/* Nút Thêm sản phẩm */}
            <Button title="Thêm Sản Phẩm" onPress={addProduct} />
        </View>
    );

}

function AddCartBike({navigation, route }) {
   const { id,name, price, img , isLiked} = route.params;
   const [liked, setLiked] = useState(isLiked);
    const toggleLike = async () => {
        // Cập nhật trạng thái liked trong state
        setLiked(!liked);

        // Cập nhật dữ liệu lên API
        try {
            const response = await fetch(`${api}/ListBike/${id}`, {
                method: 'PUT', // Sử dụng PUT để cập nhật
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    name: name,
                    price: price,
                    img: img,
                    isLiked: !liked, // Gửi trạng thái mới của liked
                }),
            });

            if (response.ok) {
                console.log('Cập nhật thành công');
            } else {
                console.log('Cập nhật không thành công');
            }
        } catch (error) {
            console.log('Lỗi khi cập nhật dữ liệu', error);
        }
    };
   const discountedPrice = price - (price * 0.15);
    return (

      <View style ={{flex : 1,margin : 10}}>
          <View style ={{flex : 1,backgroundColor :'pink',justifyContent :'center', alignItems : 'center'}}>
                <Image source={{ uri: img }} style={{ width: 300, height: 300,margin : 10, borderRadius : 10, }} />
          </View>
            <View style ={{flex : 1, marginTop : 20}}>
              <Text style={{ fontSize: 24, fontWeight: 'bold' }}>{name}</Text>
            <View  style={{flexDirection :'row'}}>
               <Text style ={{fontSize : 20,color :'grey'}}>15% OFF | {discountedPrice} </Text>
                <Text style ={{fontSize  : 20, textDecorationLine: 'line-through',marginLeft  :20}}> {price}$ </Text>
            </View>
           

<View style ={{flex  :1, marginTop : 30}}>
        <Text style ={{fontWeight : 'bold',marginBottom : 30,fontSize : 20}}>Description</Text>
       <Text style ={{fontSize : 15}}>It is a very important form of writing as we write almost everything in
        </Text>
        <Text style ={{fontSize : 15}}>paragraphs, be it an answer, essay, story, emails, etc.</Text>
      </View>

      <View style ={{flex : 1, flexDirection :'row', marginTop : 100, marginLeft : 20}}>
        <TouchableOpacity onPress={toggleLike}>
          <Icon 
            name="heart" 
            size={30} 
            color={liked ? 'red' : 'white'} 
            
            style={{ }}
          />
        </TouchableOpacity>
         <TouchableOpacity style ={{backgroundColor : "red", height : 40, width : '70%', justifyContent : 'center',alignItems :'center',borderRadius : 25, marginLeft : 20}}   onPress ={()=>{
                navigation.navigate(
                          'AddBike')
              }}>
                  <Text>Add to card</Text>
              </TouchableOpacity>
      </View>
      </View>
      


      </View>
    )
}
export const api = "https://6731c82a7aaf2a9aff120abb.mockapi.io/";
function ListBike({navigation}) {
    const [listBike,setListBike] = useState([]); 
     useEffect(()=>{
      fetchListBikeAPI();
     
    })
 const fetchListBikeAPI = async ()=>{
      try{
          const reponse = await fetch(`${api}/ListBike`)
          const data = await reponse.json();
          setListBike(data);
        }catch{
          console.log ("Loix")
        }
       
    } 

    return(
      <View style ={{flex : 1}}> 
        <View style ={{flex : 1}}>
         <View style ={{flex : 1, justifyContent : 'center'}}>
          <Text style = {{fontWeight :'bold', color:'red', marginLeft : 10, fontSize : 20, }}>The world's Best Bike</Text>
        </View>
        <View style ={{flex : 1, flexDirection :'row', justifyContent :'space-around'}}>
          <TouchableOpacity style = {{borderRadius : 5, borderWidth : 1, borderColor : 'red', height : 30, width : 100, justifyContent: 'center', alignItems :'center'}}>
            <Text>All</Text>
          </TouchableOpacity >
            <TouchableOpacity style = {{borderRadius : 5, borderWidth : 1, borderColor : 'red', height : 30, width : 100, justifyContent: 'center', alignItems :'center', }}>
            <Text>Roadbike</Text>
          </TouchableOpacity>
            <TouchableOpacity style = {{borderRadius : 5, borderWidth : 1, borderColor : 'red', height : 30, width : 100, justifyContent: 'center', alignItems :'center'}}>
            <Text>Mountain</Text>
          </TouchableOpacity>
        
        </View>
        </View>
       
        <View style={{flex : 4}}>
           <FlatList
            data ={listBike}
            keyExtractor ={item =>{item.id}}
            numColumns = "2"
            renderItem = {({item})=>(
              <View  style={{ paddingRight: 15, paddingLeft : 15, paddingTop: 5, paddingBottom  : 5,borderWidth : 1, borderColor : "#dcdcdc" , marginRight: 20,width : "47.5%", marginTop : 20,backgroundColor : 'pink', borderRadius :10}}>
                <TouchableOpacity onPress={()=>{
                 navigation.navigate(
                          'AddCartBike',{
                            id : item.id,
                            name: item.name,
                    price: item.price,
                    img: item.img,
                    isLiked :item.isLiked
                          })
                }}>
                  <View style ={{ alignItems :'center' }}>
                  <Image source = {item.img} style={{width : 120, height :  120}}/> 
                  <View style ={{justifyContent :'center', alignItems :'center',marginLeft : 10}}>
                      <Text style ={{}}>{item.name}</Text>
                       <Text style ={{fontWeight :'bold'}}>${item.price}</Text>
                  </View> 
                 
                  </View>   
                </TouchableOpacity>
                
              </View>
            )}

          />
        </View>
      </View>
    )
}

function HomeScreen({navigation}) {
return (
    <View style={{flex : 1}}>
      <View style={{flex : 1, justifyContent : 'center', alignItems :'center'}}>
          <Text style={{fontSize : 15, fontWeight : 'bold', }}>
          A premium online store for{"\n"}spoter and their stylish choise
          </Text>
          
      </View>
      <View style={{flex : 2, backgroundColor : 'pink', borderRadius : 25}}>
        <View style={{ flex : 1,alignItems : 'center', marginTop : 50}}>
           <Image style ={{height  : 300, width :300, }} source = {'https://toynotes.com/wp-content/uploads/2018/06/Mongoose-Kong-Boys-Fat-Tire-Bike.jpg'}/>
        </View>
         
      </View>
    
    <View style={{flex : 1}}>
          <View style ={{flex : 1, alignItems :'center',marginTop : 20}}>
            <Text style ={{fontSize : 20, fontWeight : 'bold'}}>POWER BIKE</Text>
            <Text style ={{fontSize : 20, fontWeight : 'bold'}}>SHOP</Text>
          </View>
          <View style ={{flex : 1,justifyContent : 'center', alignItems :'center'}}>
              <TouchableOpacity style ={{backgroundColor : "red", height : 40, width : '70%', justifyContent : 'center',alignItems :'center',borderRadius : 25}} onPress ={()=>{
                navigation.navigate(
                          'ListBike')
              }}>
                  <Text>Get Started</Text>
              </TouchableOpacity>
          </View>
    </View>
      
    </View>
  );

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
